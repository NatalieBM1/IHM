import React from  'react';
import Mainpage from  './componentes/mainpage/mainpage';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import { Homepage } from './componentes/homepage/homepage';
import { Animalespage} from './componentes/animalespage/animalespage';
import { Oceanospage } from './componentes/oceanospage/oceanospage';
import { Paisespage } from './componentes/paisespage/paisespage';


const router= createBrowserRouter([
  {
    path: "/",
    element: <Mainpage/>
  },
  {
    path: "/home",
    element: <Homepage/>
  },
  {
    path:"/animales",
    element:<Animalespage/>
  },
  {
    path:"/oceanos",
    element:<Oceanospage/>
  },
  {
    path:"/paises",
    element:<Paisespage/>
  }

]);

function App() {

  return (
    <React.Fragment>
      <RouterProvider router={router}/>
    </React.Fragment>
  )
}
export default App
