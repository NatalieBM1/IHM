import { Link } from "react-router-dom";
import "./animalespage.css"
const Animalespage = () => {
    return(
    <div>
    <nav>
      <Link to='/'><button>GALAXIAS PAGE</button></Link>
      <Link to='/home'><button>PLANETAS PAGE</button></Link>
      <Link to='/paises'><button>PAISES PAGE</button></Link>
      <Link to='/oceanos'><button>OCEANOS PAGE</button></Link>
      <Link to='/animales'><button>ANIMALES PAGE</button></Link>
    </nav>  
        <h1>ANIMALES PAGE</h1>
        <section class="main-content">
        <div class="Felinos">            
        <h2><center>FELINOS</center></h2>
        <p>Los felinos son los aquellos mamíferos carnívoros que se engloban dentro de la familia
          Felidae y de las que se conocen alrededor de 40 especies. Se trata un grupo animal de los
          más reconocidos como cazadores dentro del reino animal por ser muy sigilosos, veloces y certeros.</p>

          <p>Existen alrededor de 37 especies de felinos conocidas en el mundo, que varían desde los grandes
             felinos como el león, el tigre y el leopardo, hasta los felinos más pequeños como el gato montés
             y el gato de la selva. Estos felinos están distribuidos en diferentes hábitats alrededor del mundo,
             desde las selvas tropicales hasta las regiones áridas y montañosas. Cada especie tiene características
             únicas que la distinguen y se adaptan a su entorno particular.</p>
    
        <p>CARACTERISTICAS DE LOS FELINOS</p>
        <p>MAMIFEROS PLACENTARIOS: tienen el cuerpo cubierto de pelos, paren a sus crías ya formadas y les alimentan
          con la leche que secretan sus mamas.</p>
        <p>CARNÍVOROS: dentro de los mamíferos, los felinos pertenecen al orden Carnivora. Como el resto de integrantes
           de este orden, los felinos se alimentan de otros animales.</p>
        <p>TAMAÑO VARIABLE: los diferentes tipos de felinos pueden pesar desde 1 kg, en el caso del gato rubiginoso
           (Prionailurus rubiginosus), hasta 300 kg, en el caso del tigre (Panthera tigris).</p>
        
        <center><iframe src="https://t1.ea.ltmcdn.com/es/posts/8/1/0/curiosidades_de_felinos_salvajes_que_no_te_puedes_perder_23018_600.jpg" width="600" height="390"></iframe></center> 

        </div>
        </section>


        <section class="main-content">
        <div class="Caninos">            
        <h2><center>CANINOS</center></h2>
        <p>Los caninos, al igual que los lobos, los coyotes y otras especies, integran el grupo familiar de los cánidos.
          Esto quiere decir que son carnívoros (están preparados para comer carne) y digitígrados (se desplazan apoyando
          solamente los dedos), contando con cuatro dedos en las patas de atrás y cinco en las delanteras.</p>
    
        <p>Se estima que los caninos domésticos comenzaron a evolucionar de un ancestro en común hace unos 30.000 años.
          Existen registros de más de 10.000 años de antigüedad que revelan la existencia de un vínculo estrecho con las
           personas desde entonces, con lo cual puede decirse que ambas especies (caninos y humanos) evolucionaron juntas, 
           además, los caninos son considerados animales de trabajo. Se les suelen asignar desde tareas de vigilancia hasta
           la asistencia de individuos no videntes</p>

        <p>Existen alrededor de 38 especies de cánidos, también conocidos como miembros de la familia Canidae. Algunas de las
           especies más conocidas incluyen al perro doméstico (Canis lupus familiaris), el lobo gris (Canis lupus), el coyote
           (Canis latrans), el zorro rojo (Vulpes vulpes) y el zorro ártico (Vulpes lagopus). Estos cánidos varían en tamaño,
           hábitat y comportamiento, y se encuentran distribuidos en diversos lugares alrededor del mundo, desde regiones
           árticas hasta desiertos y selvas. </p>
        
        <center><iframe src="https://img.freepik.com/fotos-premium/manada-grupo-perros-abandonados-diferentes-razas-sentados-obedientemente-frente-camara_161299-1672.jpg" width="626" height="417"></iframe></center> 

        </div>
        </section>

        <section class="main-content">
        <div class="Selacimorfos">            
        <h2><center>SELACIMORFOS</center></h2>
        <p>Los selacimorfos (Selachimorpha) son un superorden de condrictios (peces cartilaginosos) conocidos comúnmente
          con el nombre de tiburones, o también llamados escualos. Se caracterizan por ser grandes depredadores. Los
          tiburones incluyen desde especies pequeñas de las profundidades marinas, hasta el tiburón ballena, el mayor
          de los peces, el cual se cree puede llegar a medir una longitud de 18 m y se alimenta únicamente de plancton.</p>
    
        <p>Los tiburones son condrictios peces cartilaginosos es decir, su esqueleto está hecho de cartílago en vez de hueso. 
          La piel de los tiburones está formada por una especie de escamas conocidas como dentículos dérmicos. Otra función
          de esta piel tan específica es la de actuar como un silenciador, ya que el agua se distribuye hacia dentro de las
          hendiduras y no hacia afuera, limitando la fricción contra el agua, mejorando la movilidad y velocidad y, además,
          haciendo que el desplazamiento sea mucho más silencioso.</p>

        <p>Se estima que existen alrededor de 500 especies de tiburones en el mundo. Estas especies varían enormemente en tamaño,
           forma, hábitat y comportamiento. Algunos tiburones son grandes depredadores como el gran tiburón blanco (Carcharodon
           carcharias), mientras que otros son más pequeños y se alimentan principalmente de plancton, como el tiburón ballena
           (Rhincodon typus). Entre los diferentes tipos de tiburones, se pueden encontrar especies adaptadas a una amplia gama
           de entornos marinos, desde aguas poco profundas hasta las profundidades del océano.</p>
        
        <center><iframe src="https://d7lju56vlbdri.cloudfront.net/var/ezwebin_site/storage/images/noticias/asi-evolucionaron-los-tiburones-gigantes/6417031-2-esl-MX/Asi-evolucionaron-los-tiburones-gigantes.jpg" width="600" height="400"></iframe></center> 

        </div>
        </section>

        </div>
        


    );
}
export{Animalespage } 