import { Link } from "react-router-dom";
import "./homepage.css"

const Homepage = () => {
    return(
    <div>
         <nav>
      <Link to='/'><button>GALAXIAS PAGE</button></Link>
      <Link to='/home'><button>PLANETAS PAGE</button></Link>
      <Link to='/paises'><button>PAISES PAGE</button></Link>
      <Link to='/oceanos'><button>OCEANOS PAGE</button></Link>
      <Link to='/animales'><button>ANIMALES PAGE</button></Link>
      </nav>  
        <h1>PLANETAS PAGE</h1>

        <section class="main-content">
        <div class="Venus">            
        <h2><center>PLANETA VENUS</center></h2>
        <p>Venus es el segundo planeta del sistema solar en orden de proximidad al Sol y el
            tercero más pequeño después de Mercurio y Marte. Al igual que Mercurio, carece
            de satélites naturales. Recibe su nombre en honor a Venus, la diosa romana del amor. 
            Al ser el segundo objeto natural más brillante después de la Luna, puede ser visto
            en un cielo nocturno despejado a simple vista. Aparece al despuntar el día y al 
            atardecer. Debido a las distancias de las órbitas de Venus y la Tierra desde el Sol,
            Venus nunca es visible más de tres horas antes del amanecer o tres horas después del ocaso.</p>
    
        <p>CARACTERISTICAS</p>
        <p>Tiene una atmósfera densa compuesta principalmente de dióxido de carbono y nubes de ácido sulfúrico,
            lo que genera un efecto invernadero extremadamente potente que hace que su superficie sea el lugar
            más caliente del sistema solar, con temperaturas superiores a los 450 grados Celsius.</p>
        <p>La superficie de Venus está cubierta en su mayoría por llanuras volcánicas y tiene numerosos volcanes,
            cráteres de impacto y montañas.</p>
        <p>Su rotación es muy lenta y en sentido contrario al de la mayoría de los otros planetas, lo que significa
             que su día (una rotación completa) es más largo que su año (una órbita alrededor del Sol).</p>
        
        <center><iframe src="https://imagenes.muyinteresante.es/files/image_414_276/uploads/2023/05/04/64538c7c84ede.jpeg" width="414" height="276"></iframe></center> 

        </div>
        </section>

        <section class="main-content">
        <div class="Jupiter">            
        <h2><center>PLANETA JUPITER</center></h2>
        <p>Júpiter es el planeta más grande del sistema solar y el quinto en orden de lejanía al Sol. Es un gigante
            gaseoso que forma parte de los denominados planetas exteriores. Recibe su nombre del dios romano Júpiter.
            Es uno de los objetos naturales más brillantes en un cielo nocturno despejado, superado solo por la Luna,
            Venus y algunas veces Marte. Se trata del planeta que ofrece un mayor brillo a lo largo del año dependiendo
            de su fase. Es, además, después del Sol, el mayor cuerpo celeste del sistema solar.</p>
    
        <p>CARACTERISTICAS</p>
        <p>Es un gigante gaseoso compuesto principalmente de hidrógeno y helio.</p>
        <p>Tiene una atmósfera muy turbulenta con bandas de nubes que rodean el planeta y la Gran Mancha Roja,
            una tormenta gigante que ha estado activa durante siglos.</p>
        <p>Tiene al menos 79 lunas conocidas, siendo las más grandes Io, Europa, Ganímedes y Calisto, las cuales
            son conocidas como las lunas galileanas.</p>
        
        <center><iframe src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/PIA22946-Jupiter-RedSpot-JunoSpacecraft-20190212.jpg/280px-PIA22946-Jupiter-RedSpot-JunoSpacecraft-20190212.jpg" width="280" height="280"></iframe></center> 

        </div>
        </section>

        <section class="main-content">
        <div class="Urano">            
        <h2><center>PLANETA URANO</center></h2>
        <p>Urano es el séptimo planeta del sistema solar, el tercero de mayor tamaño, y el cuarto más masivo. Se
            llama así en honor de la divinidad griega del cielo Urano. Aunque es detectable a simple vista en el
            cielo nocturno, no fue catalogado como planeta por los astrónomos de la antigüedad debido a su escasa
            luminosidad y a la lentitud de su órbita. William Herschel anunció su descubrimiento el 13 de marzo
            de 1781, ampliando las fronteras entonces conocidas del sistema solar, por primera vez en la historia
            moderna. Urano es también el primer planeta descubierto por medio de un telescopio.</p>
    
        <p>CARACTERISTICAS</p>
        <p>Es único porque su eje de rotación está inclinado casi 90 grados en relación con su plano orbital,
            lo que significa que parece girar de lado cuando se ve desde la Tierra.</p>
        <p>Tiene una atmósfera compuesta principalmente de hidrógeno, helio y metano, que le da su color azul
             verdoso característico debido a la absorción de la luz roja por el metano.</p>
        <p>Urano tiene al menos 27 lunas conocidas y un sistema de anillos. Sus lunas más grandes son Titania y Oberón.</p>
        
        <center><iframe src="https://imagenes.muyinteresante.es/files/image_414_276/uploads/2023/11/08/654b72c92b040.jpeg" width="414" height="276"></iframe></center> 

        </div>
        </section>

    </div>
    


    );
}
export{Homepage } 