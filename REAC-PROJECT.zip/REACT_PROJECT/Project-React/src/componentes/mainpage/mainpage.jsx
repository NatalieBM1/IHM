import { Link } from "react-router-dom";
import "./mainpage.css"

const Mainpage = () => {
    return(
    <div>
    <nav>
      <Link to='/'><button>GALAXIAS PAGE</button></Link>
      <Link to='/home'><button>PLANETAS PAGE</button></Link>
      <Link to='/paises'><button>PAISES PAGE</button></Link>
      <Link to='/oceanos'><button>OCEANOS PAGE</button></Link>
      <Link to='/animales'><button>ANIMALES PAGE</button></Link>
    </nav>  
        <h1>GALAXIAS PAGE</h1>        

        <section class="main-content">
        <div class="ViaLactea">            
        <h2><center>VIA LACTEA</center></h2>
        <p>La Vía Láctea es la galaxia de la cual forma parte el sistema solar,
            es decir, la galaxia en donde se encuentra la Tierra. Consiste en una
            gigantesca agrupación de estrellas, planetas y nubes de gas con forma
            de espiral barrada y un diámetro medio de alrededor de 200.000 años luz.
            En su centro habita un agujero negro súper masivo, cuya fuerza gravitacional
            mantiene los cúmulos estelares en una órbita estable.</p>
            
            <p>Es posible percibir la Vía Láctea a simple vista en una noche despejada, como una
            luz blanca borrosa que se extiende alrededor de la esfera celeste. Esto se debe a
            que el sistema solar se encuentra en una región apartada del centro, aproximadamente
            a 25.766 años luz (unos 7900 pársec), en uno de los brazos de la espiral. Al Sol le
            toma 225 millones de años terrestres completar una vuelta alrededor del centro galáctico.</p>
        
        <center><iframe src="https://media.istockphoto.com/id/1360559292/es/vector/galaxia-espiral-ilustraci%C3%B3n-de-la-v%C3%ADa-l%C3%A1ctea.jpg?s=612x612&w=0&k=20&c=qe8ezedW0fc4qxZgBGchvTh1zk7oflnaS-eGdv_sM8w=" width="612" height="408"></iframe></center> 

        </div>
        </section>

        <section class="main-content">
        <div class="Andromeda">            
        <h2><center>ANDROMEDA</center></h2>
        <p>A lo largo de la historia de la astronomía, Andrómeda ha sido observada por 
            astrónomos de renombre como Charles Messier. El astrónomo persa Al Sufi,
            en el siglo X, realizó una de las primeras observaciones, describiéndola
            como una pequeña nube en la constelación de Andrómeda. Lo asombroso es que
            la Nebulosa de Andrómeda es visible a simple vista desde lugares con cielos
            oscuros y, incluso, se puede apreciar con prismáticos desde entornos urbanos.
            En 1612, Simon Marius fue el primero en observarla con un telescopio, y en 1764,
            Charles Messier la incluyó en su famoso catálogo bajo el número 31.
        </p>
        <p>La Galaxia de Andrómeda es la galaxia espiral más grande en el Grupo Local y la galaxia
            espiral más cercana a la Vía Láctea. Está ubicada a unos 2.5 millones de años luz de
            distancia de la Tierra en la constelación de Andrómeda, tiene un diámetro estimado de
            alrededor de 220,000 años luz, lo que la hace aproximadamente un 20% más grande que la
            Vía Láctea, al igual que est, Andrómeda es una galaxia espiral con brazos espirales
            prominentes que rodean un núcleo central.</p>
        
        <center><iframe src="https://caracol.com.co/resizer/v2/EYR7G2AYNRC45HPT4JBOOA53BE.jpg?auth=54d5d50918dad71dd24b5b7376a5892c7c73eb40a6fab980f77bbb20da9b4b3e&width=650&height=488&quality=70&smart=true" width="650" height="488"></iframe></center> 

        </div>
        </section>

        <section class="main-content">
        <div class="GalaxiaSombrero">            
        <h2><center>GALAXIA DEL SOMBRERO</center></h2>
        <p>Esta galaxia luminosa y masiva tiene una masa total de unos 800 mil millones de soles,
            y es notable por su bulbo nuclear, compuesta principalmente por estrellas maduras, y
            su disco –que se aprecia casi de canto- compuesto por estrellas, gas y polvo. La
            complejidad de este polvo es evidente justo al frente del brillante núcleo, pero
            también lo es en los oscuros senderos absorbentes a través del disco. Se puede
            apreciar un gran número de objetos pequeños y difusos como un enjambre en el halo
            de Messier 104. La mayoría de ellos son cúmulos globulares, similares a los encontrados
            en nuestra propia Vía Láctea, pero Messier 104 tiene una cantidad mucho mayor. Esta galaxia
            también parece albergar un agujero negro súper masivo de alrededor de mil millones de masas
            solares, uno de los agujeros negros más masivos medidos en una galaxia cercana, y 250 veces
             más grande que el agujero negro en la Vía Láctea.</p>
                
        <center><iframe src="https://st.depositphotos.com/2361751/60639/i/450/depositphotos_606395702-stock-photo-sombrero-galaxy-open-space-elements.jpg" width="600" height="400"></iframe></center> 

        </div>
        </section>
    
    </div>
        


    );
}
export default Mainpage