import { Link } from "react-router-dom";
import "./paisespage.css"

const Paisespage = () => {
    return(
        <div>
        <nav>
      <Link to='/'><button>GALAXIAS PAGE</button></Link>
      <Link to='/home'><button>PLANETAS PAGE</button></Link>
      <Link to='/paises'><button>PAISES PAGE</button></Link>
      <Link to='/oceanos'><button>OCEANOS PAGE</button></Link>
      <Link to='/animales'><button>ANIMALES PAGE</button></Link>
      </nav> 
        <h1>PAISES PAGE</h1>
           
        <section class="main-content">
        <div class="Canada">            
        <h2><center>CANADA</center></h2>
        <p>Es comúnmente considerado uno de los países más desarrollados y con la mejor calidad de vida
            del mundo, contando con la octava economía más grande del mundo, a pesar de solo contar con
            un aproximado de 40 millones de personas. Ubicado en el extremo norte del subcontinente
            norteamericano, se extiende desde el océano Atlántico al este, el océano Pacífico al oeste,
            y hacia el norte hasta el océano Ártico.</p>
    
        <p>CARACTERISTICAS</p>
        <p>Tiene una población diversa y multicultural, con influencias de pueblos indígenas, británicos,
            franceses y otros grupos étnicos.</p>
        <p>Tiene una atmósfera compuesta principalmente de hidrógeno, helio y metano, que le da su color azul
            verdoso característico debido a la absorción de la luz roja por el metano.</p>
        <p>Es una economía desarrollada con una alta calidad de vida, con sectores económicos importantes como
            la energía, la minería, la tecnología y el turismo.</p>
        
        <center><iframe src="https://qph.cf2.quoracdn.net/main-qimg-b9ad1ffcbd63a32de77f87d37dbc56ee-lq" width="602" height="400"></iframe></center> 

        </div>
        </section>

        <section class="main-content">
        <div class="Brasil">            
        <h2><center>BRASIL</center></h2>
        <p>s un país soberano de América del Sur que comprende la mitad oriental del continente y algunos grupos
            de pequeñas islas en el océano Atlántico. Su capital es Brasilia y su ciudad más poblada es São Paulo.
            Es el tercer país más grande de América. Con una superficie estimada en más de 8 500 000 km²,es el
            quinto país más grande del mundo en área total (equivalente al 47,69 % del territorio sudamericano).
            Delimitado por el océano Atlántico al este, Brasil tiene una línea costera de 7491 km.3</p>
    
        <p>CARACTERISTICAS</p>
        <p>Es conocido por su diversidad cultural, con influencias indígenas, africanas, europeas y asiáticas.</p>
        <p>Brasil es famoso por su selva amazónica, que es la más grande del mundo y alberga una increíble biodiversidad.</p>
        <p>Tiene una economía diversificada, con sectores importantes como la agricultura, la industria manufacturera,
             la minería y el turismo.</p>
        
        <center><iframe src="https://media.istockphoto.com/id/1164402701/es/v%C3%ADdeo/vista-a%C3%A9rea-del-puente-de-estaiada-sao-paulo-brasil-centro-de-negocios-centro-financiero-gran.jpg?s=640x640&k=20&c=gMgXCSuEUNun9YNRDPfKfsIcQZ5p60eGpmnBRc4J_Bo=" width="640" height="360"></iframe></center> 

        </div>
        </section>

        <section class="main-content">
        <div class="Alemania">            
        <h2><center>ALEMANIA</center></h2>
        <p>Alemania oficialmente República Federal de Alemania, es uno de los veintisiete Estados soberanos que forman la Unión
             Europea. Constituido en Estado social y democrático de derecho, su forma de gobierno es la república parlamentaria
            y federal. Su capital es Berlín. Está formado por dieciséis estados federados (Bundesländer) y limita al norte con
            el mar del Norte, Dinamarca, Suecia (frontera marítima) y el mar Báltico; al este con Polonia y la República Checa;
            al sur con Austria y Suiza; y al oeste con Francia, Luxemburgo, Bélgica y los Países Bajos. El municipio Büsingen
            am Hochrhein, enclavado en Suiza, también forma parte de Alemania. El territorio de Alemania abarca 357 376 km² de
            extensión​ y posee un clima templado.</p>
    
        <p>CARACTERISTICAS</p>
        <p>Berlín es la capital de Alemania y una de las ciudades más importantes del país, pero otras ciudades como Hamburgo,
            Múnich y Frankfurt también son centros económicos y culturales importantes.</p>
        <p>Es la economía más grande de Europa y uno de los mayores exportadores del mundo, con sectores clave como la ingeniería,
             la automoción, la tecnología y la industria química.</p>
        <p>Alemania es conocida por su eficiencia y precisión en la ingeniería y la fabricación, así como por su énfasis en la
             sostenibilidad y la energía renovable.</p>
        
        <center><iframe src="https://ichef.bbci.co.uk/ace/ws/640/cpsprodpb/5018/production/_97940502_aleparlamento.jpg" width="640" height="360"></iframe></center> 

        </div>
        </section>

        </div>


    );
}
export{Paisespage} 