import { Link } from "react-router-dom";
import "./oceanospage.css"

const Oceanospage = () => {
    return(
    <div>
    <nav>
      <Link to='/'><button>GALAXIAS PAGE</button></Link>
      <Link to='/home'><button>PLANETAS PAGE</button></Link>
      <Link to='/paises'><button>PAISES PAGE</button></Link>
      <Link to='/oceanos'><button>OCEANOS PAGE</button></Link>
      <Link to='/animales'><button>ANIMALES PAGE</button></Link>
    </nav> 
        <h1>OCEANOS PAGE</h1>

        <section class="main-content">
        <div class="OceanoPacifico">            
        <h2><center>OCEANO PACÍFICO</center></h2>
        <p>El Pacífico es la parte del océano mundial de mayor extensión de la Tierra. Ocupa la tercera parte de su superficie y
        se extiende aproximadamente 15 500 kilómetros desde el mar de Bering limitando con el Glacial Ártico por el norte,
        hasta los márgenes congelados del mar de Ross y limitando por el sur con la Antártida. El océano Pacífico alcanza su
        mayor anchura (del orden de 19 800 km) aproximadamente a 5 grados de latitud norte, donde se extiende desde
        Indonesia hasta la costa pacífica de Colombia
        (Colombia e Indonesia son de hecho países antípodas entre sí).
        Se entiende que el límite occidental del océano está en el estrecho de Malaca. El Pacífico contiene aproximadamente
        25 000 islas (más que todos los demás océanos del mundo juntos), casi todas las cuales están ubicadas al sur de la
        línea ecuatorial. Cubre un área de 155 557 000 km².
        El punto más bajo de la superficie de la corteza terrestre, la fosa de las Marianas se encuentra en el Pacífico.
        El océano Pacífico solo se comunica con el océano Atlántico a través de cuatro conexiones: los pasos naturales en el
        extremo austral americano, el estrecho de Magallanes, el Canal de Beagle y el mar de Drake, así como una conexión
        artificial, el canal de Panamá.
        En el océano Pacífico Sur entre los 176° y 80° longitud oeste, y entre los 27° y 60° latitud sur no existen islas o
        tierra emergida.</p>        
        <center><iframe src="https://www.ambientum.com/wp-content/uploads/2020/12/bora-bora-oceano-pacifico-PIXABAY.jpg" width="647" height="431"></iframe></center> 

        </div>
        </section>

        <section class="main-content">
        <div class="OceanoAltlantico">            
        <h2><center>OCEANO ATLANTICO</center></h2>
        <p>El Atlántico es la parte del océano mundial de la Tierra que separa América —al oeste— de Europa y África —al este—.
          Se extiende desde el océano Glacial Ártico, en el norte, hasta el Antártico, en el sur. Es el segundo océano más
          extenso de la Tierra tras el Pacífico. Ocupa el 20 % de la superficie del planeta,4 y el 26 % del total de tierras
          sumergidas. Es además el océano más joven del planeta, formado hace 200 millones de años5 por la división del
          supercontinente Pangea.

          El Atlántico es un agente de importancia global en lo referente al clima, ya que de sus corrientes depende en buena
          medida el clima de los continentes ribereños. A lo largo de la historia ha supuesto una barrera cultural que ha
          separado los llamados Viejo y Nuevo Mundo hasta la llegada de la Era de los Descubrimientos, lo que supuso para el
          océano convertirse en un punto de intercambio comercial y cultural. Actualmente no ha perdido su importancia
          geoestratégica, convirtiéndose en escenario de grandes batallas desde el siglo xix hasta ser escenario de conflictos
          en la Guerra Fría.

          El ecuador terrestre lo divide artificialmente en dos partes, Atlántico Norte y Atlántico Sur. Su nombre procede del
          griego Atlas, uno de los titanes de la mitología griega. Alcanza su máxima profundidad en la fosa de Puerto Rico.

          Se comunica artificialmente con el océano Pacífico a través del canal de Panamá, de forma natural a través del
          estrecho de Magallanes y el pasaje de Drake, con el océano Índico a través del canal de Suez y el sur de África.</p>      
        <center><iframe src="https://img.freepik.com/fotos-premium/oceano-atlantico_410516-44325.jpg" width="626" height="417"></iframe></center> 

        </div>
        </section>

        <section class="main-content">
        <div class="OceanoIndico">            
        <h2><center>OCEANO ÍNDICO</center></h2>
        <p>El Índico es la parte del océano mundial de la Tierra que baña las costas de África del Este, Oriente Medio, Asia del
          Sur y Australia. Es el tercer océano más grande por superficie y cubre aproximadamente el 20 % de la superficie del
          planeta. Delimita con el Atlántico por el meridiano 20° este (cabo de las Agujas), con el Pacífico por el meridiano
          147° este y con el Antártico por el paralelo 60° sur. El punto más al norte del Índico está aproximadamente a 30°
          norte de latitud en el golfo Pérsico. ÑATAÑIE BM LA MAS LINDA El océano mide aproximadamente 10 000 km de ancho entre las puntas sur de
          África y Australia; su área es 68 556 000 km², incluyendo el mar Rojo y el golfo Pérsico. El volumen del océano se
          estima en 292 131 000 km³.

          Las naciones insulares del océano son Madagascar (cuarta isla más grande del mundo), Comoras, Seychelles, Maldivas,
          Mauricio, y Sri Lanka; Indonesia lo bordea. Sirve como una ruta de tránsito entre Asia y África lo que lo ha
          convertido en un foco de conflictos. De todas maneras, ninguna nación lo ha dominado con éxito hasta los inicios del
          siglo xix cuando los ingleses colonizaron la mayoría de la tierra perimetral. El Índico fue llamado así porque baña
          las costas de la India.</p>     
        <center><iframe src="https://static.mundoeducacao.uol.com.br/mundoeducacao/2021/05/oceano.jpg" width="600" height="402"></iframe></center> 

        </div>
        </section>
       
    </div>
        


    );
}
export{Oceanospage} 